package com.techinnovator.jmwheatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.techinnovator.jmwheatherapp.model.WeatherMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WeatherActivity extends AppCompatActivity {

    TextView txtDiffCityName, txtDiffTemp, txtDiffWeatherCondition, txtHumid, txtMax, txtMin, txtPres, txtWind;
    ImageView imgWeatherStatus;
    EditText etCityName;
    ImageButton btnSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        txtDiffCityName = findViewById(R.id.txtDiffCityName);
        txtDiffTemp = findViewById(R.id.txtDiffTemp);
        txtDiffWeatherCondition = findViewById(R.id.txtDiffWeatherCondition);
        txtHumid = findViewById(R.id.txtHumid);
        txtMax = findViewById(R.id.txtMax);
        txtMin = findViewById(R.id.txtMin);
        txtPres = findViewById(R.id.txtPres);
        txtWind = findViewById(R.id.txtWind);
        imgWeatherStatus = findViewById(R.id.imgWeatherStatus);
        etCityName = findViewById(R.id.etCityName);
        btnSearch = findViewById(R.id.btnSearch);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getWeatherData(etCityName.getText().toString());
                etCityName.setText("");
            }
        });
    }
    public void getWeatherData(String name) {
        RetrofitWeatherApi retrofitWeatherApi = RetrofitWeather.getInstance().create(RetrofitWeatherApi.class);
        Call<WeatherMap> call = retrofitWeatherApi.getWeatherWithCityName(name);

        call.enqueue(new Callback<WeatherMap>() {
            @Override
            public void onResponse(Call<WeatherMap> call, Response<WeatherMap> response) {

                if(response.isSuccessful()){
                    WeatherMap obj = response.body();
                    txtDiffCityName.setText(obj.getName()+", "+obj.getSys().getCountry());
                    txtDiffTemp.setText(obj.getMain().getTemp()+" ℃");
                    txtDiffWeatherCondition.setText(obj.getWeather().get(0).getDescription());

                    txtHumid.setText(" : "+obj.getMain().getHumidity()+"%");
                    txtMax.setText(" : "+obj.getMain().getTempMax()+" ℃");
                    txtMin.setText(" : "+obj.getMain().getTempMin()+" ℃");
                    txtPres.setText(" : "+obj.getMain().getPressure());
                    txtWind.setText(" : "+obj.getWind().getSpeed());

                    String img = obj.getWeather().get(0).getIcon();
                    Picasso.get().load("https://openweathermap.org/img/wn/"+img+"@2x.png").into(imgWeatherStatus);
                }
                else{
                    Toast.makeText(WeatherActivity.this, "City not found", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<WeatherMap> call, Throwable t) {
                System.out.println(t.toString());
            }
        });

    }
}