package com.techinnovator.jmwheatherapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.techinnovator.jmwheatherapp.model.WeatherMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TextView txtCityName, txtTemp, txtWeatherCondition, txtHumidity, txtMaxTemp, txtMinTemp, txtPressure, txtWindSpeed;
    ImageView imgStatus;
    ImageButton btnAdd;
    LocationManager locationManager;
    LocationListener locationListener;
    ProgressBar progressBar;
    double lat;
    double lon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCityName = findViewById(R.id.txtCityName);
        txtTemp = findViewById(R.id.txtTemp);
        txtWeatherCondition = findViewById(R.id.txtWeatherCondition);
        txtHumidity = findViewById(R.id.txtHumidity);
        txtMaxTemp = findViewById(R.id.txtMaxTemp);
        txtMinTemp = findViewById(R.id.txtMinTemp);
        txtPressure = findViewById(R.id.txtPressure);
        txtWindSpeed = findViewById(R.id.txtWindSpeed);
        progressBar = findViewById(R.id.progressBar);

        imgStatus = findViewById(R.id.imgStatus);
        btnAdd = findViewById(R.id.btnAdd);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, WeatherActivity.class));
            }
        });
        progressBar.setVisibility(View.INVISIBLE);
        getWeatherData();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                lat = location.getLatitude();
                lon = location.getLongitude();
                progressBar.setVisibility(View.VISIBLE);
                getWeatherData(lat, lon);
            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                System.out.println("provider");
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                System.out.println("status");
            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                System.out.println("provider disabled");
            }
        };


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1, 50, locationListener);
        }

    }

    public void getWeatherData(double lat, double lon) {
        RetrofitWeatherApi retrofitWeatherApi = RetrofitWeather.getInstance().create(RetrofitWeatherApi.class);
        Call<WeatherMap> call = retrofitWeatherApi.getWeatherWithLocation(lat, lon);

        call.enqueue(new Callback<WeatherMap>() {
            @Override
            public void onResponse(Call<WeatherMap> call, Response<WeatherMap> response) {
                WeatherMap obj = response.body();
                System.out.println("lat and lon");
                txtCityName.setText(obj.getName()+", "+obj.getSys().getCountry());
                txtTemp.setText(obj.getMain().getTemp()+" ℃");
                txtWeatherCondition.setText(obj.getWeather().get(0).getDescription());

                txtHumidity.setText(" : "+obj.getMain().getHumidity()+"%");
                txtMaxTemp.setText(" : "+obj.getMain().getTempMax()+" ℃");
                txtMinTemp.setText(" : "+obj.getMain().getTempMin()+" ℃");
                txtPressure.setText(" : "+obj.getMain().getPressure());
                txtWindSpeed.setText(" : "+obj.getWind().getSpeed());

                String img = obj.getWeather().get(0).getIcon();
                Picasso.get().load("https://openweathermap.org/img/wn/"+img+"@2x.png").into(imgStatus);
                progressBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onFailure(Call<WeatherMap> call, Throwable t) {
                System.out.println(t.toString());
            }
        });

    }

    public void getWeatherData() {
        RetrofitWeatherApi retrofitWeatherApi = RetrofitWeather.getInstance().create(RetrofitWeatherApi.class);
        Call<WeatherMap> call = retrofitWeatherApi.getWeatherWithCityName("Rajkot");

        call.enqueue(new Callback<WeatherMap>() {
            @Override
            public void onResponse(Call<WeatherMap> call, Response<WeatherMap> response) {

                if(response.isSuccessful()){
                    WeatherMap obj = response.body();
                    System.out.println(obj.getName());
                    txtCityName.setText(obj.getName()+", "+obj.getSys().getCountry());
                    txtTemp.setText(obj.getMain().getTemp()+" ℃");
                    txtWeatherCondition.setText(obj.getWeather().get(0).getDescription());

                    txtHumidity.setText(" : "+obj.getMain().getHumidity()+"%");
                    txtMaxTemp.setText(" : "+obj.getMain().getTempMax()+" ℃");
                    txtMinTemp.setText(" : "+obj.getMain().getTempMin()+" ℃");
                    txtPressure.setText(" : "+obj.getMain().getPressure());
                    txtWindSpeed.setText(" : "+obj.getWind().getSpeed());

                    String img = obj.getWeather().get(0).getIcon();
                    Picasso.get().load("https://openweathermap.org/img/wn/"+img+"@2x.png").into(imgStatus);
                }
            }

            @Override
            public void onFailure(Call<WeatherMap> call, Throwable t) {
                System.out.println(t.toString());
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && permissions.length > 0 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 50, locationListener);
        }
    }
}