package com.techinnovator.jmwheatherapp;

import com.techinnovator.jmwheatherapp.model.WeatherMap;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitWeatherApi {

    @GET("weather?appid=9879534b5e1e7494f6c6f9dcaa0433ea&units=metric")
    Call<WeatherMap> getWeatherWithLocation(@Query("lat") double lat, @Query("lon") double lon);

    @GET("weather?appid=9879534b5e1e7494f6c6f9dcaa0433ea&units=metric")
    Call<WeatherMap> getWeatherWithCityName(@Query("q") String cityName);
}
